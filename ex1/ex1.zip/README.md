Gal Cesana galce
